# scrcpy_stream
A small package for easily and continuously capturing screenshots from scrcpy
